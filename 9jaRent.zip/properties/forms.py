from django import forms
from .models import Property, PropertyImage

class PropertyForm(forms.ModelForm):
    images = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=False)
    
    class Meta:
        model = Property
        fields = ['title', 'description', 'price', 'state', 'lga', 'area', 'property_type', 'bedrooms', 'bathrooms', 'agent_name', 'agent_whatsapp', 'agent_email', 'video']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
        }
